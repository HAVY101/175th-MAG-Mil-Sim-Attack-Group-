livery = {
	{"A-10C_PAINT_1-a", 0 ,"A-10_1a_raum",false};
	{"A-10C_PAINT_1-b", 0 ,"A-10_1-b_175th",false};
	{"A-10C_PAINT_1-c", 0 ,"A-10_1-c_175th",false};
	{"A-10C_PAINT_1-d", 0 ,"A-10_1-d_175th",false};
	{"A-10C_PAINT_1-e", 0 ,"A-10_1-e_175th",false};
	{"A-10C_PAINT_1-f", 0 ,"A-10_1-f_175th",false};
	{"A-10C_PAINT_1-g", 0 ,"A-10_1-g_175th",false};
	{"A-10C_PAINT_1-h", 0 ,"A-10_1-h_175th",false};
	{"A-10C_PAINT_1-i", 0 ,"A-10_1-i_175th",false};
	{"A-10C_PAINT_1-j", 0 ,"A-10_1-j_175th",false};
	{"A-10C_PAINT_1-k", 0 ,"A-10_1-k_175th",false};
	{"A-10C_PAINT_1-L", 0 ,"A-10_1-L_175th",false};
	{"A-10_Number", 0 ,"empty",true};
	{"A-10_Number_Noze_F", 0 ,"empty",true};
	{"A-10_Number_Noze_T", 0 ,"empty",true};
	{"A-10_Number_Wheel", 0 ,"empty",true};
	{"pilot_A10",    DIFFUSE            ,    "pilot_a10_175th", false};
}
name = '36th Fighter Squadron - Raumteufel'